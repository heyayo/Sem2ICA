ANGRY BIRDS but just a bunch of cubes and circles

Collisions:
CubeToCube
SphereToCube
SphereToLine
SphereToSphere

